# Kcal & Macros Calculator

Static offline-capable calculator ready for GitHub Pages.
